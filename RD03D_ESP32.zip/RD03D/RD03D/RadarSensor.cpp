// RadarSensor.cpp
#include "RadarSensor.h"
#include <math.h>

RadarSensor::RadarSensor(HardwareSerial& uart)
  : serial_(uart) {
  // Initialize target to known state
  target_ = {};
  target_.detected = false;
}

void RadarSensor::begin(uint32_t baud, int8_t rxPin, int8_t txPin) {
  // ESP32 HardwareSerial can (optionally) remap pins at begin().
  // If rxPin/txPin are -1, we don't force a remap.
  if (rxPin >= 0 && txPin >= 0) {
    serial_.begin(baud, SERIAL_8N1, rxPin, txPin);
  } else {
    serial_.begin(baud, SERIAL_8N1);
  }
}

// Parser state machine.
// We look for header AA FF 03 00, then read the following 26 bytes (24 payload + 2 tail).
bool RadarSensor::update() {
  // Buffer for "after header" bytes only (payload+tail)
  static uint8_t buf_after_header[26];
  static size_t idx = 0;

  enum State : uint8_t { WAIT_AA, WAIT_FF, WAIT_03, WAIT_00, READ_AFTER_HEADER };
  static State state = WAIT_AA;

  bool updated = false;

  while (serial_.available() > 0) {
    const uint8_t b = static_cast<uint8_t>(serial_.read());

    switch (state) {
      case WAIT_AA:
        if (b == 0xAA) state = WAIT_FF;
        break;

      case WAIT_FF:
        if (b == 0xFF) state = WAIT_03;
        else state = WAIT_AA;
        break;

      case WAIT_03:
        if (b == 0x03) state = WAIT_00;
        else state = WAIT_AA;
        break;

      case WAIT_00:
        if (b == 0x00) {
          idx = 0;
          state = READ_AFTER_HEADER;
        } else {
          state = WAIT_AA;
        }
        break;

      case READ_AFTER_HEADER:
        buf_after_header[idx++] = b;

        if (idx >= sizeof(buf_after_header)) {
          // Verify tail
          const uint8_t tail0 = buf_after_header[24];
          const uint8_t tail1 = buf_after_header[25];

          if (tail0 == 0x55 && tail1 == 0xCC) {
            // Parse payload (first 24 bytes)
            updated = parsePayload24_(buf_after_header, 24);
          }

          // Resync for next frame
          idx = 0;
          state = WAIT_AA;
        }
        break;
    }
  }

  return updated;
}

bool RadarSensor::parsePayload24_(const uint8_t* p, size_t len) {
  if (len != 24) return false;

  // Only parse first target (bytes 0..7). Targets 2 and 3 are p[8..15], p[16..23].
  const uint16_t raw_x_u = static_cast<uint16_t>(p[0] | (static_cast<uint16_t>(p[1]) << 8));
  const uint16_t raw_y_u = static_cast<uint16_t>(p[2] | (static_cast<uint16_t>(p[3]) << 8));
  const uint16_t raw_speed_u = static_cast<uint16_t>(p[4] | (static_cast<uint16_t>(p[5]) << 8));
  const uint16_t raw_pixel_u = static_cast<uint16_t>(p[6] | (static_cast<uint16_t>(p[7]) << 8));

  const int16_t x = decodeVendorSigned15_(raw_x_u);
  const int16_t y = decodeVendorSigned15_(raw_y_u);
  const int16_t sp = decodeVendorSigned15_(raw_speed_u);

  target_.x_mm = x;
  target_.y_mm = y;
  target_.speed_cms = static_cast<float>(sp);
  target_.pixel_dist_mm = raw_pixel_u;

  target_.detected = !(raw_x_u == 0 && raw_y_u == 0 && raw_speed_u == 0 && raw_pixel_u == 0);

  if (!target_.detected) {
    target_.distance_mm = 0.0f;
    target_.angle_deg = 0.0f;
    return true;
  }

  // Distance in mm (derived)
  const float xf = static_cast<float>(x);
  const float yf = static_cast<float>(y);
  target_.distance_mm = sqrtf(xf * xf + yf * yf);

  /*
    Angle convention:
      Vendor diagram defines +Y as "forward" and +X as lateral.
      A natural "bearing from forward" is atan2(x, y) (not atan2(y, x)).

      angle_deg = 0 means straight ahead (+Y).
      angle_deg positive means +X direction.
  */
  const float angle_rad = atan2f(xf, yf);
  target_.angle_deg = angle_rad * (180.0f / PI);

  return true;
}

RadarTarget RadarSensor::getTarget() const {
  return target_;
}

int16_t RadarSensor::decodeVendorSigned15_(uint16_t raw) {
  // bit15: 1 => positive, 0 => negative (per vendor doc)
  const int16_t mag = static_cast<int16_t>(raw & 0x7FFF);
  const bool positive = (raw & 0x8000) != 0;
  return positive ? mag : static_cast<int16_t>(-mag);
}