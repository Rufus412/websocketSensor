// RadarSensor.h
#ifndef RADARSENSOR_H
#define RADARSENSOR_H

#include <Arduino.h>

/*
  RD-03D frame (fixed length):
    Header: AA FF 03 00
    Payload: 3 targets * 8 bytes = 24 bytes
      target i:
        x (int16, mm, sign in bit15 per vendor doc)
        y (int16, mm, sign in bit15 per vendor doc)
        speed (int16, cm/s, sign in bit15; negative means approaching)
        pixel_dist (uint16, mm)  // vendor calls it "pixel distance value"
    Tail: 55 CC

  Total bytes after header: 24 payload + 2 tail = 26 bytes
*/

struct RadarTarget {
  float distance_mm;   // Derived from x/y (mm)
  float angle_deg;     // Derived from x/y (degrees), convention noted in .cpp
  float speed_cms;     // cm/s
  int16_t x_mm;        // mm
  int16_t y_mm;        // mm
  uint16_t pixel_dist_mm;
  bool detected;
};

class RadarSensor {
public:
  // Prefer hardware UART on ESP32: e.g. HardwareSerial& uart = Serial2;
  explicit RadarSensor(HardwareSerial& uart);

  // On ESP32 you can pass rx/tx pins to bind the UART to chosen GPIOs.
  // If rxPin/txPin are omitted, it uses whatever pins are already configured for that UART.
  void begin(uint32_t baud = 256000, int8_t rxPin = -1, int8_t txPin = -1);

  // Call frequently; returns true when a valid frame was parsed and target was updated.
  bool update();

  // Returns the most recently parsed target (only target1 is parsed by this library)
  RadarTarget getTarget() const;

private:
  HardwareSerial& serial_;
  RadarTarget target_;

  bool parsePayload24_(const uint8_t* payload24, size_t len);

  // Vendor sign rule: bit15 is sign flag (1=positive, 0=negative), magnitude in low 15 bits
  static int16_t decodeVendorSigned15_(uint16_t raw);
};

#endif  // RADARSENSOR_H